# Change Log

All notable changes to this project will be documented in this file. See [standard-version](https://github.com/conventional-changelog/standard-version) for commit guidelines.

<a name="1.0.0"></a>
# [1.0.0](https://github.com/istanbuljs/istanbul-lib-hook/compare/v1.0.0-alpha.3...v1.0.0) (2017-01-17)


### Bug Fixes

* update append-transform to version that fixes issues run into by ts-node ([f4aaf79](https://github.com/istanbuljs/istanbul-lib-hook/commit/f4aaf79))
