# Change Log

All notable changes to this project will be documented in this file. See [standard-version](https://github.com/conventional-changelog/standard-version) for commit guidelines.

<a name="1.0.1"></a>
## [1.0.1](https://github.com/istanbuljs/istanbul-lib-coverage/compare/v1.0.0...v1.0.1) (2017-01-18)


### Bug Fixes

* handle edge-case surrounding merging two file coverage reports ([22e154c](https://github.com/istanbuljs/istanbul-lib-coverage/commit/22e154c))



<a name="1.0.0"></a>
# [1.0.0](https://github.com/istanbuljs/istanbul-lib-coverage/compare/v1.0.0-alpha.3...v1.0.0) (2016-08-12)


### Bug Fixes

* guard against missing statement ([76aad99](https://github.com/istanbuljs/istanbul-lib-coverage/commit/76aad99))
